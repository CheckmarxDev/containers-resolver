import logging
import requests
import os

BASE_URL = os.getenv('BASE_URL', 'https://static-ci.dev.cxast.net/')
IAMURL = os.getenv('ACCESS_CONTROL', 'https://iam.checkmarx.net')
CLIENT_ID = os.getenv('CLIENT_ID', 'ast-app')
TENANT_NAME = os.getenv('TENANT_NAME')
USER_NAME = os.getenv('USER_NAME')
PASSWORD = os.getenv('PASSWORD')
token = ''

def get_token():
    try:
        auth_url = IAMURL + '/auth/realms/' + TENANT_NAME + '/protocol/openid-connect/token'
        headers = {
            'Content-type': 'application/x-www-form-urlencoded',
            'Sec-Fetch-Site': 'same-site',
            'Accept': '*/*',
            'Accept-Encoding': 'gzip, deflate, br'
        }
        params = {
            'client_id': CLIENT_ID,
            'grant_type': 'password',
            'username':USER_NAME,
            'password':PASSWORD,
        }
        response = requests.post(auth_url, data=params, headers=headers)
        logging.info('response.status_code: ', response.status_code)
        response.raise_for_status()
        jsonResponse = response.json()
        access_token = jsonResponse['access_token']
        return access_token
    except Exception as e:
        logging.error(f'Error getting Access Control token, Error: {e}')

def get_projects(token):
    try:
        base_url = BASE_URL + 'api/projects/?offset=0&limit=2500'
        headers = {
            'Accept': 'application/json; version=1.0',
            'Authorization': token
        }
        response = requests.get(base_url, headers=headers)
        logging.info('response.status_code: ', response.status_code)
        response.raise_for_status()
        return response.json()['projects']
    except Exception as e:
        logging.error(f'Error getting projects data, Error: {e}')

def get_scans(token):
    try:
        base_url = BASE_URL + 'api/scans/?offset=0&limit=2500'
        headers = {
            'Accept': 'application/json; version=1.0',
            'Authorization': token
        }
        response = requests.get(base_url, headers=headers)
        logging.info('response.status_code: ', response.status_code)
        response.raise_for_status()
        return response.json()['scans']
    except Exception as e:
        logging.error(f'Error getting scans data, Error: {e}')

def get_policies(token):
    try:
        base_url = BASE_URL + 'api/policy_management_service_uri/policies/v2/?limit=2500&page=1'
        headers = {
            'Accept': 'application/json',
            'Authorization': token
        }
        response = requests.get(base_url, headers=headers)
        logging.info('response.status_code: ', response.status_code)
        response.raise_for_status()
        return response.json()['policies']
    except Exception as e:
        logging.error(f'Error getting policies data, Error: {e}')


def delete_project(token, scan_id):
    try:
        url = BASE_URL + 'api/projects/' + scan_id
        headers = {
            'Accept': '*/*',
            'Authorization': token
        }
        print(f'Deleting project: {scan_id}')
        response = requests.delete(url, headers=headers)
        logging.info('response.status_code: ', response.status_code)
        response.raise_for_status()
    except Exception as e:
        logging.error(f'Error Deleting project, Error: {e}')

def cancel_scan(token, scan_id):
    try:
        url = BASE_URL + 'api/scans/' + scan_id
        headers = {
            'Accept': '*/*',
            'Authorization': token
        }
        data = '{"status":"Canceled"}'
        print(f'Canceling scan: {scan_id}')
        response = requests.patch(url, data=data,headers=headers)
        logging.info('response.status_code: ', response.status_code)
        response.raise_for_status()
    except Exception as e:
        logging.error(f'Error Canceling scan, Error: {e}')

def delete_policy(token, policy_id):
    try:
        url = BASE_URL + f'api/policy_management_service_uri/policies/?id={policy_id}'
        headers = {
            'Accept': '*/*',
            'Authorization': token
        }
        print(f'Deleting policy: {policy_id}')
        response = requests.delete(url, headers=headers)
        logging.info('response.status_code: ', response.status_code)
        response.raise_for_status()
    except Exception as e:
        logging.error(f'Error Deleting policy, Error: {e}')


def main():
    print(f'BASE_URL: {BASE_URL}, Keycloack URL: {IAMURL}, ClientID: {CLIENT_ID}, TENANT_NAME {TENANT_NAME}, USER_NAME {USER_NAME} PASSWORD {PASSWORD}  ')
    token = get_token()

    scans = get_scans(token)
    print(f'scans={scans}')
    if type(scans) == list:
        for scan in scans:
            print(f'Scan ID: {scan["id"]}, Status: {scan["status"]}')
            if scan['status'] == 'Running':
                cancel_scan(token, scan['id'])

    projects = get_projects(token)
    print(f'projects={projects}')
    if type(projects) == list:
        for project in projects:
            print(f'Project Name: {project["name"]}, Project ID: {project["id"]}')
            delete_project(token, project['id'])

    policies = get_policies(token)
    print(f'policies={policies}')
    if type(policies) == list:
        for policy in policies:
            print(f'Policy Name: {policy["name"]}, Policy ID: {policy["id"]}')
            delete_policy(token, policy['id'])

if __name__ == '__main__':
    main()

# containers-worker
The containers engine's scan entry point in CxOne platform
